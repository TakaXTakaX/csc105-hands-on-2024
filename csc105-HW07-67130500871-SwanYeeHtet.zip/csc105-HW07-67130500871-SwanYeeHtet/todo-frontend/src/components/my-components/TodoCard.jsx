import React from "react";
import { Button } from "../ui/button";
import { FaRegCircle, FaRegDotCircle } from "react-icons/fa";

const TodoCard = ({
  id,
  success,
  name,
  handleSuccessToggle,
  handleSave,
  handleEdit,
  handleDelete,
  editingId,
  editingText,
  handleInputChange,
  handleKeyDown,
}) => {
  return (
    <div
      key={id}
      className="flex gap-4 items-center bg-neutral-100 border border-neutral-300 rounded-xl p-4"
    >
      {/* Success Toggle */}
      <span
        onClick={handleSuccessToggle}
        className="cursor-pointer text-xl text-black"
      >
        {success ? <FaRegDotCircle /> : <FaRegCircle />}
      </span>

      {/* Todo Text or Edit Input */}
      {editingId === id ? (
        <input
          value={editingText}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          className="border-b border-neutral-400 outline-none w-full bg-transparent text-black"
        />
      ) : (
        <h1
          className={`${
            success ? "line-through text-neutral-500" : "text-black"
          } break-words flex-grow min-w-0`}
        >
          {name}
        </h1>
      )}

      {/* Buttons */}
      <div className="ml-auto flex gap-2">
        {editingId === id ? (
          <Button variant="outline" size="sm" onClick={handleSave}>
            Save
          </Button>
        ) : (
          <Button variant="outline" size="sm" onClick={handleEdit}>
            Edit
          </Button>
        )}

        <Button
          variant="outline"
          size="sm"
          onClick={handleDelete}
          className={success ? "cursor-not-allowed text-neutral-400" : ""}
          disabled={success}
        >
          X
        </Button>
      </div>
    </div>
  );
};

export default TodoCard;
